function mostrarNombre() {
  let nombre = document.getElementById("evaluar").value;
  escribirNombre(nombre);
}

function escribirNombre(nombre) {
  let nombre1 = nombre;
  //let regex = /^[Escribe]+[(]+["]+[rapo]+["]+[)]+[;]/;
  let regex = /[Escribe("");]/; //Escribe("LKAFLAJDSKLFA");
  let regex2 = /[""]/;
  let regex3 = /\n/;
  //^[A-Za-z]+\.[a-z]+\.[a-z]+\s*[(" A-Za-z0-9")]+\;
  let nuevaCadena;
  let arreglo;
  let otravariable;
  nuevaCadena = regex.test(nombre1);
  //console.log(nuevaCadena);
  if (nuevaCadena == true) {
    arreglo = nombre1.split(regex2);
    console.log(arreglo);
    document.formL.validar.value = arreglo[1];
  } else {
    alert("Verifica la Sintaxis");
  }
}

///////////////////////////////////////////////////////////////////////////

function mostrarAlerta() {
  let nombre = document.getElementById("evaluarAlerta").value;
  escribirAlerta(nombre);
}

function escribirAlerta(nombre) {
  let nombre1 = nombre;
  let regex = /[Alerta("");]/; //Escribe("LKAFLAJDSKLFA");
  let regex2 = /[""]/;
  let regex3 = /\n/;
  //^[A-Za-z]+\.[a-z]+\.[a-z]+\s*[(" A-Za-z0-9")]+\;
  let nuevaCadena;
  let arreglo;
  let otravariable;
  nuevaCadena = regex.test(nombre1);
  //console.log(nuevaCadena);
  if (nuevaCadena == true) {
    arreglo = nombre1.split(regex2);
    console.log(arreglo);
    alert(arreglo[1]);
  } else {
    alert("Verifica la Sintaxis");
  }
}
console.log();

/////////////////////////////////////////////////////////////////////////////

function mostrarConsole() {
  let nombre = document.getElementById("evaluarConsole").value;
  escribirConsole(nombre);
}

function escribirConsole(nombre) {
  let nombre1 = nombre;
  let regex = /[Escribe.consola("");]/; //Escribe("LKAFLAJDSKLFA");
  let regex2 = /[""]/;
  let regex3 = /\n/;
  //^[A-Za-z]+\.[a-z]+\.[a-z]+\s*[(" A-Za-z0-9")]+\;
  let nuevaCadena;
  let arreglo;
  let otravariable;
  nuevaCadena = regex.test(nombre1);
  //console.log(nuevaCadena);
  if (nuevaCadena == true) {
    arreglo = nombre1.split(regex2);
    console.log(arreglo[1]);
  } else {
    alert("Verifica la Sintaxis");
  }
}

/////////////////////////////////////////////////////////////////////

function mostrarVariable() {
  let nombre = document.getElementById("evaluarVariable").value;
  escribirVariable(nombre);
}

function escribirVariable(nombre) {
  let nombre1 = nombre;
  let regex = /[variable = ;]+[Escribe("");]/; //Escribe("LKAFLAJDSKLFA");
  let regex2 = /[= ;]/;
  let regex3 = /\n/;
  //^[A-Za-z]+\.[a-z]+\.[a-z]+\s*[(" A-Za-z0-9")]+\;
  let nuevaCadena;
  let arreglo;
  let otravariable;
  nuevaCadena = regex.test(nombre1);
  //console.log(nuevaCadena);
  if (nuevaCadena == true) {
    arreglo = nombre1.split(regex2);
    console.log(nombre);
    document.formL.validarVariable.value = arreglo[1];
  } else {
    alert("Verifica la Sintaxis");
  }
}

var a = 15;
var b = 15;
var suma = a + b;
console.log(suma);
