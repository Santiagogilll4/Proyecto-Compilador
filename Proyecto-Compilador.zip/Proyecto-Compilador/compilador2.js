function mostrarNombre() {
  let nombre = document.getElementById("cadenaEvaluar").value;
  escribirNombre(nombre);
}

function escribirNombre(nombre) {
  //Expresiones Regulares
  let regex = /[E][s][c][r][i][b][e]/g;
  let regex1 = /;$/g;
  let regex2 = /[""]/g;
  //Otras variables
  let nombre1 = nombre;
  let nuevaCadena;
  let nuevaCadena2;
  //Arreglos
  let arreglo = new Array();
  let arreglo2 = new Array();
  //Variables
  nuevaCadena = regex.test(nombre1);
  nuevaCadena2 = regex1.test(nombre1);
  if (nuevaCadena == true && nuevaCadena2 == true) {
    arreglo = nombre1.split(regex2);
    if (arreglo.length == 3) {
      document.Formulario.cadenaValidar.value = arreglo[1];
    }
    if (arreglo.length == 5) {
      document.Formulario.cadenaValidar.value = arreglo[1] + "\n" + arreglo[3];
    }
    if (arreglo.length == 7) {
      document.Formulario.cadenaValidar.value =
        arreglo[1] + "\n" + arreglo[3] + "\n" + arreglo[5];
    }
    if (arreglo.length == 9) {
      document.Formulario.cadenaValidar.value =
        arreglo[1] + "\n" + arreglo[3] + "\n" + arreglo[5] + "\n" + arreglo[7];
    }
  } else {
    alert("Verifica la Sintaxis");
  }
}

function operaciones() {
  //Recibimiento de variables
  let operacion = document.getElementById("cadenaEvaluar").value;
  //Expresiones Regulares
  let regex = /int [a-z] = \d;/g;
  let regex2 = /[\s;]/g;
  let regex3 = /[0-9]+/;
  let regex4 = /(suma|resta|multiplicacion|division)/;
  //Otras variables
  let aceptacion;
  //Arreglos
  let arreglo = new Array();
  let arreglo2 = new Array();
  //Variables para operaciones
  let var1;
  let var2;
  let var1_1;
  let var2_2;
  let var3;
  let resultado;
  //Variables
  aceptacion = regex.test(operacion);
  if (aceptacion == true) {
    arreglo = operacion.split(regex2);

    for (let i = 0; i < arreglo.length; i++) {
      var1 = arreglo[i];
      var2 = regex3.test(var1);
      if (var2 == true) {
        arreglo2.push(arreglo[i]);
      }
    }

    document.addEventListener("keyup", function (event) {
      if (event.keyCode == 13) {
        if (regex4.test(arreglo) == true) {
          console.log("Arreglo 11" + arreglo[11]);
          var3 = arreglo[10];
          var1_1 = parseInt(arreglo2[0]);
          var2_2 = parseInt(arreglo2[1]);
          if (var3 == "suma") {
            resultado = var1_1 + var2_2;
          } else if (var3 == "resta") {
            resultado = var1_1 - var2_2;
          } else if (var3 == "multiplicacion") {
            resultado = var1_1 * var2_2;
          } else if (var3 == "division") {
            resultado = var1_1 / var2_2;
          }
          document.Formulario.cadenaValidar.value = "resultado: " + resultado;
        } else {
          document.Formulario.cadenaValidar.value = arreglo2 + "\n";
        }
      }
    });
    console.log(arreglo);
  } else {
    alert("Verifica la Sintaxis");
  }
}

function limpiar() {
  Formulario.reset();
}
